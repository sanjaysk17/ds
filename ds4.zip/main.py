class ChessGame:
    def __init__(self):
        self.board = [
            ['r','n','b','q','k','b','n','r'],
            ['p','p','p','p','p','p','p','p'],
            [' ',' ',' ',' ',' ',' ',' ',' '],
            [' ',' ',' ',' ',' ',' ',' ',' '],
            [' ',' ',' ',' ',' ',' ',' ',' '],
            [' ',' ',' ',' ',' ',' ',' ',' '],
            ['P','P','P','P','P','P','P','P'],
            ['R','N','B','Q','K','B','N','R']
        ]
        self.white_turn = True
        self.history = []   # 🔥 store moves

    def print_board(self):
        for row in self.board:
            print(' '.join(row))
        print()

    # Pawn moves
    def get_pawn_moves(self, row, col):
        moves = []
        piece = self.board[row][col]
        direction = -1 if piece.isupper() else 1

        if 0 <= row + direction < 8 and self.board[row + direction][col] == ' ':
            moves.append((row + direction, col))

        return moves

    def get_piece_moves(self, row, col):
        piece = self.board[row][col].lower()
        if piece == 'p':
            return self.get_pawn_moves(row, col)
        return []

    def is_valid_move(self, row, col, new_row, new_col):
        if new_row < 0 or new_row >= 8 or new_col < 0 or new_col >= 8:
            return False
        if self.board[new_row][new_col].isupper() == self.white_turn:
            return False
        return (new_row, new_col) in self.get_piece_moves(row, col)

    # 🔹 Make move
    def make_move(self, row, col, new_row, new_col):
        piece = self.board[row][col]
        captured = self.board[new_row][new_col]

        # Save move for undo
        self.history.append((row, col, new_row, new_col, captured))

        self.board[new_row][new_col] = piece
        self.board[row][col] = ' '

        self.white_turn = not self.white_turn

    # 🔥 Undo move (BACKTRACKING)
    def undo_move(self):
        if not self.history:
            print("No moves to undo")
            return

        row, col, new_row, new_col, captured = self.history.pop()

        self.board[row][col] = self.board[new_row][new_col]
        self.board[new_row][new_col] = captured

        self.white_turn = not self.white_turn

    def play_game(self):
        while True:
            self.print_board()

            print("White's turn" if self.white_turn else "Black's turn")

            cmd = input("Enter move (e.g., a2 a3) or 'undo': ")

            # 🔥 Backtracking feature
            if cmd == "undo":
                self.undo_move()
                continue

            try:
                source, destination = cmd.split()
            except:
                print("Invalid input")
                continue

            source_col = ord(source[0]) - ord('a')
            source_row = 8 - int(source[1])
            dest_col = ord(destination[0]) - ord('a')
            dest_row = 8 - int(destination[1])

            if self.is_valid_move(source_row, source_col, dest_row, dest_col):
                self.make_move(source_row, source_col, dest_row, dest_col)
            else:
                print("Invalid move")


# Run
game = ChessGame()
game.play_game()